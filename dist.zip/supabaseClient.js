import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://grzeqiwbitpmmkpsuvsr.supabase.co'; // შენი პროექტის URL
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImdyemVxaXdiaXRwbW1rcHN1dnNyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTM4OTIyODIsImV4cCI6MjA2OTQ2ODI4Mn0.FbtueLxLAB7sgmNSXTr2pV7lJRyHPZYy-q-tuFLXKi8'; // ჩასვი შენი პროექტის anon key აქ

export const supabase = createClient(supabaseUrl, supabaseAnonKey);