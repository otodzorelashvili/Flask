import { useState, useEffect, useRef } from 'react';
import { createClient } from '@supabase/supabase-js';
import EmojiPicker from 'emoji-picker-react'; // ემოჯების ამომრჩევის იმპორტი
import './App.css'; // დარწმუნდით, რომ გაქვთ ეს CSS ფაილი სტილებისთვის
import logo from './logo.png';
import newMessageSound from './mixkit-long-pop-2358.wav';
import cardFlickSound from './mixkit-poker-card-flick-2002.wav';
import turnStartSound from './magic-game-key-picked-up-epic-stock-media-1-00-03.mp3'; // თქვენი სვლის ხმა

// Supabase კლიენტის ინიციალიზაცია
// შეცვალეთ თქვენი Supabase URL-ით და Anon Key-ით
const supabaseUrl = 'https://grzeqiwbitpmmkpsuvsr.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImdyemVxaXdiaXRwbW1rcHN1dnNyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTM4OTIyODIsImV4cCI6MjA2OTQ2ODI4Mn0.FbtueLxLAB7sgmNSXTr2pV7lJRyHPZYy-q-tuFLXKi8';
const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Flask (Uno) ბარათების ტიპები და ფერები
const COLORS = ['red', 'green', 'blue', 'yellow'];
const VALUES = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'skip', 'reverse', 'draw2'];
const WILD_VALUES = ['wild', 'wild_draw4'];

// სტანდარტული Flask (Uno) დასტის შესაქმნელი ფუნქცია
const createDeck = () => {
  let deck = [];
  // დანომრილი ბარათები (0-9, თითოეული 1-9 ორ-ორი, ერთი 0)
  COLORS.forEach(color => {
    deck.push({ color, value: '0' });
    for (let i = 1; i <= 9; i++) {
      deck.push({ color, value: String(i) });
      deck.push({ color, value: String(i) });
    }
    // სპეციალური ბარათები (skip, reverse, draw2 - თითოეული ფერისთვის ორ-ორი)
    ['skip', 'reverse', 'draw2'].forEach(value => {
      deck.push({ color, value });
      deck.push({ color, value });
    });
  });
  // ველური ბარათები (ოთხ-ოთხი)
  WILD_VALUES.forEach(value => {
    for (let i = 0; i < 4; i++) {
      deck.push({ color: 'wild', value }); // 'wild' როგორც ფერი ველური ბარათებისთვის
    }
  });
  return shuffleDeck(deck);
};

// დასტის არევის ფუნქცია
const shuffleDeck = (deck) => {
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }
  return deck;
};



// ბარათის ტექსტის ჩვენების დამხმარე ფუნქცია (განახლებული ქართული თარგმანით)
const getCardDisplayText = (card) => {
  if (!card) return '';
  switch (card.value) {
    case 'skip': // SVG-ს გამოსაყენებლად, ტექსტს ვაცარიელებთ
      return '';
    case 'reverse': // SVG-ს გამოსაყენებლად, ტექსტს ვაცარიელებთ
      return '';
    case 'draw2':
      return '+2';
    case 'wild':
      return 'WILD'; // ტექსტი, რომელსაც გრადიენტით გავაფორმებთ
    case 'wild_draw4':
      return '+4';
    default:
      return card.value;
  }
};

// Helper function to get the symbol for card corners
const getCardCornerSymbol = (card) => {
  if (!card) return '';
  switch (card.value) {
    case 'skip': // SVG-ს გამოსაყენებლად, კუთხის სიმბოლოს ვაცარიელებთ
      return '';
    case 'reverse': // SVG-ს გამოსაყენებლად, კუთხის სიმბოლოს ვაცარიელებთ
      return '';
    case 'draw2':
      return '+2';
    case 'wild':
      return ''; // ნამდვილ Wild ბარათს კუთხეში სიმბოლო არ აქვს
    case 'wild_draw4':
      return '+4';
    default:
      return card.value;
  }
};

// ხმოვანი ეფექტი ჩატისთვის
const chatAudio = new Audio(newMessageSound);
// ხმოვანი ეფექტი კარტისთვის
const cardAudio = new Audio(cardFlickSound);
// ხმოვანი ეფექტი სვლისთვის
const turnAudio = new Audio(turnStartSound);

// მოწყობილობის ხატულების კომპონენტები
const MobileIcon = () => (
  <svg version="1.1" viewBox="0 0 32 32" className="device-icon">
    <path stroke="currentColor" fill="none" strokeWidth="2" strokeMiterlimit="10" d="M21,27H11c-1.1,0-2-0.9-2-2V7c0-1.1,0.9-2,2-2h10c1.1,0,2,0.9,2,2v18C23,26.1,22.1,27,21,27z"/>
    <circle fill="currentColor" cx="16" cy="24" r="1"/>
  </svg>
);

const DesktopIcon = () => (
  <svg version="1.1" viewBox="0 0 32 32" className="device-icon">
    <path stroke="currentColor" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" d="M3,6v15c0,1.1,0.9,2,2,2h22c1.1,0,2-0.9,2-2V6c0-1.1-0.9-2-2-2H5C3.9,4,3,4.9,3,6z"/>
    <line stroke="currentColor" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" x1="9" y1="29" x2="23" y2="29"/>
    <path stroke="currentColor" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" d="M13,23c0,2.1-0.7,4.6-1.8,6"/>
    <path stroke="currentColor" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" d="M20.8,29c-1.1-1.4-1.8-3.9-1.8-6"/>
  </svg>
);

const SkipIcon = () => (
  <svg width="60px" height="60px" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg" className="skip-icon">
    {/* fill="#222" უზრუნველყოფს, რომ ხატულა მუქი იყოს და გამოჩნდეს თეთრ ფონზე */}
    <g>
      <path fill="#222" d="M33.2,24,22.6,34.6a1.9,1.9,0,0,0,.2,3,2.1,2.1,0,0,0,2.7-.2l11.9-12a1.9,1.9,0,0,0,0-2.8l-11.9-12a2.1,2.1,0,0,0-2.7-.2,1.9,1.9,0,0,0-.2,3Z"/>
      <path fill="#222" d="M21.2,24,10.6,34.6a1.9,1.9,0,0,0,.2,3,2.1,2.1,0,0,0,2.7-.2l11.9-12a1.9,1.9,0,0,0,0-2.8l-11.9-12a2.1,2.1,0,0,0-2.7-.2,1.9,1.9,0,0,0-.2,3Z"/>
    </g>
  </svg>
);

const ReverseIcon = () => (
  <svg width="60px" height="60px" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="reverse-icon">
    <path d="M4 7H14C17.3137 7 20 9.68629 20 13C20 16.3137 17.3137 19 14 19H4M4 7L8 3M4 7L8 11" stroke="#222" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

const SettingsIcon = () => (
<svg width="24px" height="24px" viewBox="0 0 1024 1024" xmlns="http://www.w3.org/2000/svg"><path fill="#ffffff4d" d="M600.704 64a32 32 0 0 1 30.464 22.208l35.2 109.376c14.784 7.232 28.928 15.36 42.432 24.512l112.384-24.192a32 32 0 0 1 34.432 15.36L944.32 364.8a32 32 0 0 1-4.032 37.504l-77.12 85.12a357.12 357.12 0 0 1 0 49.024l77.12 85.248a32 32 0 0 1 4.032 37.504l-88.704 153.6a32 32 0 0 1-34.432 15.296L708.8 803.904c-13.44 9.088-27.648 17.28-42.368 24.512l-35.264 109.376A32 32 0 0 1 600.704 960H423.296a32 32 0 0 1-30.464-22.208L357.696 828.48a351.616 351.616 0 0 1-42.56-24.64l-112.32 24.256a32 32 0 0 1-34.432-15.36L79.68 659.2a32 32 0 0 1 4.032-37.504l77.12-85.248a357.12 357.12 0 0 1 0-48.896l-77.12-85.248A32 32 0 0 1 79.68 364.8l88.704-153.6a32 32 0 0 1 34.432-15.296l112.32 24.256c13.568-9.152 27.776-17.408 42.56-24.64l35.2-109.312A32 32 0 0 1 423.232 64H600.64zm-23.424 64H446.72l-36.352 113.088-24.512 11.968a294.113 294.113 0 0 0-34.816 20.096l-22.656 15.36-116.224-25.088-65.28 113.152 79.68 88.192-1.92 27.136a293.12 293.12 0 0 0 0 40.192l1.92 27.136-79.808 88.192 65.344 113.152 116.224-25.024 22.656 15.296a294.113 294.113 0 0 0 34.816 20.096l24.512 11.968L446.72 896h130.688l36.48-113.152 24.448-11.904a288.282 288.282 0 0 0 34.752-20.096l22.592-15.296 116.288 25.024 65.28-113.152-79.744-88.192 1.92-27.136a293.12 293.12 0 0 0 0-40.256l-1.92-27.136 79.808-88.128-65.344-113.152-116.288 24.96-22.592-15.232a287.616 287.616 0 0 0-34.752-20.096l-24.448-11.904L577.344 128zM512 320a192 192 0 1 1 0 384 192 192 0 0 1 0-384zm0 64a128 128 0 1 0 0 256 128 128 0 0 0 0-256z"/></svg>
);

const SoundIcon = ({ muted }) => (
    <svg fill="currentColor" width="24px" height="24px" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" className="setting-icon">
        {muted ? (
            <path d="M16.5 12c0-1.77-1.02-3.29-2.5-4.03v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51C20.63 14.91 21 13.5 21 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3L3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06c1.38-.31 2.63-.95 3.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4L9.91 6.09 12 8.18V4z"/>
        ) : (
            <path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z"/>
        )}
    </svg>
);

const AnimationIcon = () => (
    <svg fill="currentColor" width="24px" height="24px" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" className="setting-icon">
        <path d="M19,2H5A2,2,0,0,0,3,4V20a2,2,0,0,0,2,2H19a2,2,0,0,0,2-2V4A2,2,0,0,0,19,2Zm-8,15H10V15h1Zm0-3H10V12h1Zm0-3H10V9h1Zm3,6H13V15h1Zm0-3H13V12h1Zm0-3H13V9h1Zm3,6H16V15h1Zm0-3H16V12h1Zm0-3H16V9h1Z"/>
    </svg>
);

const ExitIcon = () => (
  <svg width="24px" height="24px" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <g clipPath="url(#clip0_exit_icon)">
      <path d="M15 4.00098H5V18.001C5 19.1055 5.89543 20.001 7 20.001H15" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"/>
      <path d="M16 15.001L19 12.001M19 12.001L16 9.00098M19 12.001H9" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"/>
    </g>
    <defs>
      <clipPath id="clip0_exit_icon">
        <rect fill="white" height="24" transform="translate(0 0.000976562)" width="24"/>
      </clipPath>
    </defs>
  </svg>
);

const ErrorIcon = () => (
  <svg fill="currentColor" width="24px" height="24px" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" className="setting-icon">
    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/>
  </svg>
);

const truncateUsername = (name, maxLength = 5) => {
  if (typeof name !== 'string' || !name) return '';
  if (name.length > maxLength) {
    return name.slice(0, maxLength) + '...';
  }
  return name;
};

function SettingsModal({ onClose, soundVolume, onSoundVolumeChange, animationsEnabled, onAnimationsChange }) {
  return (
    <div className="settings-modal-overlay" onClick={onClose}>
      <div className="settings-modal" onClick={(e) => e.stopPropagation()}>
        <div className="settings-modal-header">
          <h2>პარამეტრები</h2>
          <button onClick={onClose} className="close-button" aria-label="Close settings">
          </button>
        </div>
        <div className="settings-modal-content">
          <div className="setting-item">
            <div className="setting-label-group">
              <SoundIcon muted={soundVolume === 0} />
              <label htmlFor="sound-volume">ხმის ეფექტები</label>
            </div>
            <div className="volume-control">
              <input
                type="range"
                id="sound-volume"
                min="0"
                max="1"
                step="0.1"
                value={soundVolume}
                onChange={(e) => onSoundVolumeChange(parseFloat(e.target.value))}
                className="volume-slider"
                style={{ '--value': `${soundVolume * 100}%` }}
              />
              <span>{Math.round(soundVolume * 100)}%</span>
            </div>
          </div>
          <div className="setting-item">
            <div className="setting-label-group">
              <AnimationIcon />
              <label htmlFor="animations-toggle">ანიმაციები</label>
            </div>
            <label className="toggle-switch">
              <input type="checkbox" id="animations-toggle" checked={animationsEnabled} onChange={(e) => onAnimationsChange(e.target.checked)} />
              <span className="slider round"></span>
            </label>
          </div>
        </div>
      </div>
    </div>
  );
}

function ColorPickerModal({ onColorSelect, onClose }) {
  return (
    <div className="color-picker-modal-overlay" onClick={onClose}>
      <div className="color-picker-modal" onClick={(e) => e.stopPropagation()}>
        <h3>აირჩიეთ ფერი</h3>
        <div className="color-picker-options">
          {COLORS.map(color => (
            <button
              key={color}
              className={`color-option-button ${color}`}
              onClick={() => onColorSelect(color)}
              aria-label={`Select ${color}`}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

function ErrorModal({ message, onClose }) {
  useEffect(() => {
    const handleEsc = (event) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleEsc);

    // კომპონენტის დაშლისას მსმენელის მოშორება
    return () => {
      window.removeEventListener('keydown', handleEsc);
    };
  }, [onClose]);

  if (!message) return null;

  return (
    <div className="error-modal-overlay" onClick={onClose}>
      <div className="error-modal" onClick={(e) => e.stopPropagation()}>
        <div className="error-modal-header">
          <div className="error-modal-title-group">
            <ErrorIcon />
            <h3>შეცდომა</h3>
          </div>
          <button onClick={onClose} className="close-button">&times;</button>
        </div>
        <div className="error-modal-content">
          <p>{message}</p>
        </div>
        <div className="error-modal-footer">
            <button onClick={onClose} className="primary-button">
              დახურვა
            </button>
        </div>
      </div>
    </div>
  );
}

function App() {
  const [username, setUsername] = useState('');
  // ახალი მდგომარეობები პაროლისა და ავტორიზაციის რეჟიმისთვის
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [authMode, setAuthMode] = useState('login'); // 'login' or 'register'

  const [roomName, setRoomName] = useState('');
  const [roomKey, setRoomKey] = useState('');
  const [user, setUser] = useState(null);
  const [room, setRoom] = useState(null);
  const [error, setError] = useState('');
  const [gameState, setGameState] = useState(null); // ეს შეიძლება შეიცავდეს თამაშის ფაზას (მაგ. 'waiting', 'playing', 'bot_game')
  const [isAdminView, setIsAdminView] = useState(false); // ადმინის გვერდისთვის
  const [roomUsers, setRoomUsers] = useState([]);
  const [isBotGameOption, setIsBotGameOption] = useState(false);
  const [isRoomCreator, setIsRoomCreator] = useState(false); // ახალი მდგომარეობა იმის შესამოწმებლად, არის თუ არა მიმდინარე მომხმარებელი ოთახის შემქმნელი

  // ოთახის შექმნის/შესვლის რეჟიმი
  const [roomMode, setRoomMode] = useState('join'); // 'join' or 'create'
  const [maxPlayers, setMaxPlayers] = useState(4);
  const [createRoomPassword, setCreateRoomPassword] = useState('');

  // New state for existing rooms list
  const [existingRooms, setExistingRooms] = useState([]);
  const [showExistingRooms, setShowExistingRooms] = useState(false);

  // Flask (Uno) თამაშის სპეციფიკური მდგომარეობები
  const [playerHands, setPlayerHands] = useState({}); // { userId: [card1, card2, ...], bot: [card1, ...] }
  const [drawPile, setDrawPile] = useState([]);
  const [discardPile, setDiscardPile] = useState([]);
  const [animatingCardInfo, setAnimatingCardInfo] = useState(null); // For card playing animation
  const [currentTurnPlayerId, setCurrentTurnPlayerId] = useState(null); // მომხმარებლის ID ან 'bot'
  const [gameDirection, setGameDirection] = useState(1); // 1 საათის ისრის მიმართულებით, -1 საათის ისრის საწინააღმდეგოდ
  const [pendingDrawAmount, setPendingDrawAmount] = useState(0); // Draw2/Draw4 დაგროვებისთვის
  const [activeWildColor, setActiveWildColor] = useState(null); // ველური ბარათებისთვის, არჩეული ფერი
  const [gameMessage, setGameMessage] = useState(''); // შეტყობინება, რომელიც ნაჩვენებია მომხმარებლისთვის (მაგ. "თქვენი სვლაა!", "X იმარჯვებს!")
  const [winningPlayer, setWinningPlayer] = useState(null); // ინახავს გამარჯვებული მოთამაშის მომხმარებლის ID-ს, 'draw'-ს ან null-ს

  // ჩატის სპეციფიკური მდგომარეობები
  const [chatMessages, setChatMessages] = useState([]);
  const [newChatMessage, setNewChatMessage] = useState('');
  const chatMessagesEndRef = useRef(null);
  const discardPileRef = useRef(null); // For card animation target
  const prevChatMessagesLength = useRef(0); // წინა შეტყობინებების რაოდენობის შესანახად
  const playerHandRef = useRef(null); // ახალი ref მოთამაშის ხელის კონტეინერისთვის
  const [showScrollButtons, setShowScrollButtons] = useState({ left: false, right: false }); // სქროლის ღილაკების ჩვენების მდგომარეობა
  const [showTurnNotification, setShowTurnNotification] = useState(false);

  // ემოჯი-რეაქციებისთვის
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [reactions, setReactions] = useState([]);
  const [userDeviceTypes, setUserDeviceTypes] = useState({}); // { userId: 'mobile' | 'desktop' }
  const [windowWidth, setWindowWidth] = useState(window.innerWidth);

  // Drag-to-scroll-ისთვის ref-ები
  const isDraggingRef = useRef(false);
  const startXRef = useRef(0);
  const scrollLeftRef = useRef(0);

  // Settings State
  const [showSettings, setShowSettings] = useState(false);
  const [soundEffectsVolume, setSoundEffectsVolume] = useState(1);
  const [enableAnimations, setEnableAnimations] = useState(true);

  const [showColorPicker, setShowColorPicker] = useState(false);
  const [wildCardToPlay, setWildCardToPlay] = useState(null); // Will store { index, startRect }

  const roomUsersRef = useRef(roomUsers); // Ref უახლეს roomUsers-ზე წვდომისთვის ეფექტებში/callback-ებში
  const isProcessingMoveRef = useRef(false); // Ref სვლის დამუშავებისას განახლებების ბლოკირებისთვის

  useEffect(() => {
    roomUsersRef.current = roomUsers;
  }, [roomUsers]);

  // ფანჯრის ზომის ცვლილების მსმენელი
  useEffect(() => {
    const handleResize = () => {
      setWindowWidth(window.innerWidth);
    };  
    window.addEventListener('resize', handleResize);
    // კომპონენტის დაშლისას მსმენელის მოშორება
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const playSound = (audio, volume) => {
    audio.volume = volume;
    audio.play().catch(error => console.error("ხმის დაკვრის შეცდომა:", error));
  };

  // ჩატის შეტყობინებების ბოლოში გადახვევა და ხმის დაკვრა
  useEffect(() => {
    if (chatMessagesEndRef.current) {
      chatMessagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
    // ხმის დაკვრა ახალ შეტყობინებაზე (მაგრამ არა საკუთარზე)
    if (chatMessages.length > 0 && chatMessages.length > prevChatMessagesLength.current) {
      const lastMessage = chatMessages[chatMessages.length - 1];
      if (user && lastMessage.user_id !== user.id) {
        playSound(chatAudio, soundEffectsVolume);
      }
    }
    prevChatMessagesLength.current = chatMessages.length;
  }, [chatMessages, user]); // user დამატებულია დამოკიდებულებებში

  const prevTurnPlayerId = useRef(null);
  useEffect(() => {
    // შეტყობინების ჩვენება, როდესაც მომხმარებლის სვლაა
    if (
      currentTurnPlayerId === user?.id &&
      prevTurnPlayerId.current !== user?.id &&
      !winningPlayer
    ) {
      setShowTurnNotification(true);
      playSound(turnAudio, soundEffectsVolume); // თქვენი სვლის ხმის დაკვრა
      const timer = setTimeout(() => {
        setShowTurnNotification(false);
      }, 4000); // 4 წამში გაქრობა

      return () => clearTimeout(timer);
    }
    prevTurnPlayerId.current = currentTurnPlayerId;
  }, [currentTurnPlayerId, user, winningPlayer, soundEffectsVolume]);

  // თამაშის მდგომარეობის გადატვირთვა, როდესაც ოთახის game_started_at ხდება null
  // ფუნქცია იმის შესამოწმებლად, საჭიროა თუ არა სქროლის ღილაკები
  const checkScrollability = () => {
    const el = playerHandRef.current;
    if (el) {
      // მცირე ტოლერანტობა ემატება შედარებას ქვეპიქსელური რენდერინგის პრობლემების თავიდან ასაცილებლად.
      const tolerance = 2;
      const hasOverflow = el.scrollWidth > el.clientWidth + tolerance;
      setShowScrollButtons({
        left: hasOverflow && el.scrollLeft > 0,
        right: hasOverflow && el.scrollLeft < el.scrollWidth - el.clientWidth - tolerance,
      });
    }
  };

  // სქროლის შესაძლებლობის შემოწმება ჩატვირთვისას, ზომის შეცვლისას და ბარათების შეცვლისას
  useEffect(() => {
    // მცირე დაყოვნება, რათა დარწმუნდეთ, რომ DOM სრულად არის დახატული შემოწმებამდე
    const timer = setTimeout(checkScrollability, 100);
    window.addEventListener('resize', checkScrollability);
    
    return () => {
      clearTimeout(timer);
      window.removeEventListener('resize', checkScrollability);
    };
  }, [playerHands, user, gameState]); // ასევე შეამოწმეთ, როდესაც gameState იცვლება (მაგ. თამაში იწყება)

  const handleScroll = (direction) => {
    const el = playerHandRef.current;
    if (el) {
      const scrollAmount = direction === 'left' ? -el.clientWidth * 0.8 : el.clientWidth * 0.8;
      el.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };

  // Drag-to-scroll-ის დამმუშავებლები
  const handleMouseDown = (e) => {
    const el = playerHandRef.current;
    // დაიწყოს დრაგინგი მხოლოდ იმ შემთხვევაში, თუ სქროლი შესაძლებელია და დაჭერილია მაუსის მარცხენა ღილაკი
    if (!el || el.scrollWidth <= el.clientWidth || e.button !== 0) return;
    
    isDraggingRef.current = true;
    startXRef.current = e.pageX - el.offsetLeft;
    scrollLeftRef.current = el.scrollLeft;
    el.classList.add('grabbing');
  };

  const handleMouseLeaveOrUp = () => {
    const el = playerHandRef.current;
    if (el && isDraggingRef.current) {
      isDraggingRef.current = false;
      el.classList.remove('grabbing');
    }
  };

  const handleMouseMove = (e) => {
    if (isDraggingRef.current) {
      e.preventDefault(); // ტექსტის მონიშვნის და სხვა დეფოლტ ქცევების თავიდან არიდება
      const el = playerHandRef.current;
      const x = e.pageX - el.offsetLeft;
      const walk = (x - startXRef.current) * 2; // გამრავლება აჩქარებს სქროლს
      el.scrollLeft = scrollLeftRef.current - walk;
      checkScrollability();
    }
  };

  // ახალი სარეგისტრაციო ფუნქცია
  const handleRegister = async () => {
    if (!username || !password || !confirmPassword) {
      setError('გთხოვთ, შეავსოთ ყველა ველი');
      return;
    }
    if (password !== confirmPassword) {
      setError('პაროლები არ ემთხვევა');
      return;
    }
    setError('');

    try {
      let { data: existingUser, error: selectError } = await supabase
        .from('users')
        .select('id')
        .eq('username', username)
        .single();

      if (selectError && selectError.code !== 'PGRST116') {
        setError('მომხმარებლის შემოწმების შეცდომა: ' + selectError.message);
        return;
      }

      if (existingUser) {
        setError('მომხმარებლის სახელი უკვე დაკავებულია');
        return;
      }

      // გაფრთხილება: პაროლი ინახება დაუშიფრავად. ეს არ არის უსაფრთხო.
      // რეალურ აპლიკაციაში გამოიყენეთ პაროლის დაჰეშვა სერვერზე ან Supabase Auth.
      const { data, error: insertError } = await supabase
        .from('users')
        .insert([{ username, password }])
        .select();

      if (insertError) {
        setError('მომხმარებლის შექმნის შეცდომა: ' + insertError.message);
        return;
      }

      // შევამოწმოთ, რომ მონაცემები დაბრუნდა insert-ის შემდეგ
      if (!data || data.length === 0) {
        setError('რეგისტრაცია წარმატებული იყო, მაგრამ მომხმარებლის მონაცემების მიღება ვერ მოხერხდა.');
        return;
      }
      setUser(data[0]);
    } catch (err) {
      setError('მოულოდნელი შეცდომა რეგისტრაციის დროს: ' + err.message);
    }
  };

  // ახალი ავტორიზაციის ფუნქცია
  const handleLogin = async () => {
    if (!username || !password) {
      setError('გთხოვთ, შეიყვანოთ მომხმარებლის სახელი და პაროლი');
      return;
    }
    setError('');

    try {
      let { data: userToLogin, error: selectError } = await supabase
        .from('users')
        .select('*')
        .eq('username', username)
        .single();

      if (selectError || !userToLogin) {
        setError('არასწორი მომხმარებლის სახელი ან პაროლი');
        return;
      }

      // გაფრთხილება: დაუშიფრავი პაროლის შედარება. ეს არ არის უსაფრთხო.
      if (userToLogin.password !== password) {
        setError('არასწორი მომხმარებლის სახელი ან პაროლი');
        return;
      }

      setUser(userToLogin);
    } catch (err) {
      setError('მოულოდნელი შეცდომა ავტორიზაციის დროს: ' + err.message);
    }
  };

  // ოთახის შექმნის დამმუშავებელი
  const handleCreateRoom = async () => {
    if (!roomName) {
      setError('გთხოვთ, შეიყვანოთ ოთახის სახელი');
      return;
    }
    if (!user) {
      setError('გთხოვთ, ჯერ გაიაროთ ავტორიზაცია.');
      return;
    }
    setError('');

    try {
      // შეამოწმეთ, არსებობს თუ არა ოთახი იგივე სახელით
      let { data: existingRoom, error: fetchRoomError } = await supabase
        .from('rooms')
        .select('id')
        .eq('name', roomName)
        .single();

      if (fetchRoomError && fetchRoomError.code !== 'PGRST116') {
        throw fetchRoomError;
      }

      if (existingRoom) {
        setError('ამ სახელის მქონე ოთახი უკვე არსებობს.');
        return;
      }

      // ახალი ოთახის შექმნა
      const { data: newRoom, error: createRoomError } = await supabase
        .from('rooms')
        .insert([{
          name: roomName,
          room_key: createRoomPassword, // პაროლი შექმნისას
          created_by: user.id,
          max_players: maxPlayers // მოთამაშეების მაქს. რაოდენობა
        }])
        .select()
        .single();

      if (createRoomError) {
        throw createRoomError;
      }

      // მომხმარებლის current_room_id-ის განახლება
      const { error: updateUserRoomError } = await supabase
        .from('users')
        .update({ current_room_id: newRoom.id })
        .eq('id', user.id);

      if (updateUserRoomError) {
        throw updateUserRoomError;
      }
      
      setRoom(newRoom);
      setIsRoomCreator(true);

    } catch (err) {
      setError(`ოთახის შექმნის შეცდომა: ${err.message}`);
    }
  };

  // ოთახში შესვლის დამმუშავებელი
  const handleJoinRoom = async () => {
    if (!roomName) {
      setError('გთხოვთ, შეიყვანოთ ოთახის სახელი');
      return;
    }
    if (!user) {
      setError('გთხოვთ, ჯერ გაიაროთ ავტორიზაცია.');
      return;
    }
    setError('');

    try {
      let { data: roomToJoin, error: fetchRoomError } = await supabase
        .from('rooms')
        .select('*')
        .eq('name', roomName)
        .single();

      if (fetchRoomError || !roomToJoin) {
        setError('ოთახი ამ სახელით არ მოიძებნა.');
        return;
      }

      // პაროლის შემოწმება, თუ ოთახს აქვს პაროლი
      if (roomToJoin.room_key && roomToJoin.room_key !== roomKey) {
        setError('არასწორი პაროლი');
        return;
      }

      // შეამოწმეთ, სავსეა თუ არა ოთახი
      const { count, error: countError } = await supabase
        .from('users')
        .select('*', { count: 'exact', head: true })
        .eq('current_room_id', roomToJoin.id);

      if (countError) throw countError;

      if (roomToJoin.max_players && count >= roomToJoin.max_players) {
        setError('ოთახი სავსეა.');
        return;
      }

      // იგივე ლოგიკა, როგორც joinRoom-ში იყო
      await supabase.from('users').update({ current_room_id: roomToJoin.id }).eq('id', user.id);
      setRoom(roomToJoin);
      setIsRoomCreator(user.id === roomToJoin.created_by);

    } catch (err) {
      setError(`ოთახში შესვლის შეცდომა: ${err.message}`);
    }
  };

  // ერთიანი, საიმედო ფუნქცია ყველა მონაცემის სერვერიდან იძულებით გასაახლებლად
  const forceRefreshAllData = async () => {
    // თუ სვლა მუშავდება, გამოტოვეთ განახლება, რათა თავიდან ავიცილოთ ოპტიმისტური UI-ს გადაწერა
    if (isProcessingMoveRef.current || !room?.id || !user?.id) {
      if (isProcessingMoveRef.current) console.log(`[${new Date().toLocaleTimeString()}] განახლება გამოტოვებულია სვლის დამუშავების გამო.`);
      return;
    }

    console.log(`[${new Date().toLocaleTimeString()}] ყველა მონაცემის იძულებითი განახლება ოთახისთვის: ${room.id}`);

    try {
      // ოთახის, მომხმარებლების და ჩატის მონაცემების პარალელურად მოზიდვა ეფექტურობისთვის
      const [roomResponse, usersResponse, chatResponse] = await Promise.all([
        supabase.from('rooms').select('*, game_state_data').eq('id', room.id).single(),
        supabase.from('users').select('id, username').eq('current_room_id', room.id),
        supabase.from('chat_messages').select('*, users(username)').eq('room_id', room.id).order('created_at', { ascending: true })
      ]);

      // 1. ოთახის და თამაშის მდგომარეობის დამუშავება
      const { data: updatedRoom, error: roomError } = roomResponse;
      if (roomError) {
        console.error('განახლების შეცდომა (ოთახი):', roomError.message);
      } else if (updatedRoom) {
        setRoom(updatedRoom);
        const isGameStarted = !!updatedRoom.game_started_at;
        const newGameStateData = updatedRoom.game_state_data;

        // თამაშის ტიპის განსაზღვრა game_state_data-დან
        const isBotGame = newGameStateData?.playerHands && 'bot' in newGameStateData.playerHands;

        if (isGameStarted) {
          const newGameType = isBotGame ? 'bot_game' : 'multiplayer';
          // gameState-ის განახლება მხოლოდ იმ შემთხვევაში, თუ ის არ არის სწორად დაყენებული, ან თუ დაწყების სტატუსი იცვლება
          if (!gameState || gameState.started !== isGameStarted || gameState.type !== newGameType) {
            setGameState({ type: newGameType, started: true });
          }
        } else {
          // თუ თამაში არ არის დაწყებული, gameState უნდა იყოს null
          if (gameState) {
            setGameState(null);
          }
        }

        if (newGameStateData) {
          const {
            playerHands, drawPile, discardPile, currentTurnPlayerId, gameDirection,
            pendingDrawAmount, activeWildColor, winningPlayer
          } = newGameStateData;

          setPlayerHands(playerHands || {});
          setDrawPile(drawPile || []);
          setDiscardPile(discardPile || []);
          setCurrentTurnPlayerId(currentTurnPlayerId || null);
          setGameDirection(gameDirection !== undefined ? gameDirection : 1);
          setPendingDrawAmount(pendingDrawAmount !== undefined ? pendingDrawAmount : 0);
          setActiveWildColor(activeWildColor || null);
          setWinningPlayer(winningPlayer || null);
        } else {
          // თუ თამაში დასრულდა ან თავიდან დაიწყო, ვასუფთავებთ მდგომარეობას
          setPlayerHands({});
          setDrawPile([]);
          setDiscardPile([]);
          setCurrentTurnPlayerId(null);
          setGameDirection(1);
          setPendingDrawAmount(0);
          setActiveWildColor(null);
          setWinningPlayer(null);
        }
      }

      // 2. მომხმარებლების სიის დამუშავება
      const { data: usersData, error: usersError } = usersResponse;
      if (usersError) {
        console.error('მომხმარებლების სიის განახლების შეცდომა:', usersError.message);
      } else if (usersData) {
        setRoomUsers(usersData);
        // ბოტის თამაშის ოფციის ჩვენების ლოგიკა
        const isCreatorAlone = usersData.length === 1 && user.id === updatedRoom?.created_by;
        setIsBotGameOption(isCreatorAlone);
      }

      // 3. ჩატის შეტყობინებების დამუშავება
      const { data: chatData, error: chatError } = chatResponse;
      if (chatError) {
        console.error('ჩატის განახლების შეცდომა:', chatError.message);
      } else if (chatData) {
        setChatMessages(chatData);
      }

    } catch (err) {
      console.error('ყველა მონაცემის განახლების მოულოდნელი შეცდომა:', err.message);
    }
  };

  // ეფექტი, რომელიც მართავს რეალურ დროში კავშირს და 3-წამიან პერიოდულ განახლებას
  useEffect(() => {
    let channel = null;
    let chatChannel = null;
    let intervalId = null;

    if (room?.id && user) { // *** FIX: Depend on room.id to prevent re-subscriptions on every game state change ***
      setIsRoomCreator(user.id === room.created_by);

      // პირველადი მონაცემების მოზიდვა ოთახში შესვლისთანავე
      forceRefreshAllData();

      // 3-წამიანი ინტერვალის დაყენება გარანტირებული განახლებისთვის
      intervalId = setInterval(forceRefreshAllData, 3000);

      // Supabase რეალურ დროში გამოწერების დაყენება
      channel = supabase
        .channel(`room_users_channel:${room.id}`) // უნიკალური არხის სახელი
        .on(
          'postgres_changes',
          { event: '*', schema: 'public', table: 'users' },
          () => { console.log('რეალურ დროში ცვლილება (users), ვაიძულებთ განახლებას...'); forceRefreshAllData(); }
        )
        .on(
          'broadcast',
          { event: 'emoji_reaction' },
          (payload) => {
            if (payload.payload.senderId !== user.id) {
              // ემოჯის ანიმაციისთვის და ავტომატური წაშლისთვის
              const reactionId = Date.now() + Math.random();
              const newReaction = {
                id: reactionId,
                emoji: payload.payload.emoji,
                style: {
                  left: `${Math.random() * 80 + 10}%`, // შემთხვევითი ჰორიზონტალური პოზიცია
                }
              };
              setReactions(currentReactions => [...currentReactions, newReaction]);
              setTimeout(() => {
                setReactions(currentReactions => currentReactions.filter(r => r.id !== reactionId));
              }, 2900); // ანიმაციის დასრულებამდე ცოტა ხნით ადრე წაშლა
            }
          }
        )
        .on( // ახალი მსმენელი მოწყობილობის ინფორმაციისთვის
          'broadcast',
          { event: 'device_info' },
          (payload) => {
            const { userId, deviceType } = payload.payload;
            setUserDeviceTypes(prev => ({ ...prev, [userId]: deviceType }));
          }
        )
        .on( // ახალი მსმენელი მოთხოვნებისთვის
          'broadcast',
          { event: 'request_device_info' },
          () => {
            // ვიღაც ითხოვს ჩვენს მოწყობილობის ინფორმაციას, ამიტომ ვაგზავნით.
            const myDeviceType = window.innerWidth <= 900 ? 'mobile' : 'desktop';
            channel.send({
              type: 'broadcast',
              event: 'device_info',
              payload: { userId: user.id, deviceType: myDeviceType },
            });
          }
        )
        .on(
          'postgres_changes',
          { event: '*', schema: 'public', table: 'rooms', filter: `id=eq.${room.id}` },
          () => { console.log('რეალურ დროში ცვლილება (rooms), ვაიძულებთ განახლებას...'); forceRefreshAllData(); }
        )
        .subscribe((status) => {
          if (status === 'SUBSCRIBED') {
            console.log(`წარმატებით გამოიწერა არხი: room_users_channel:${room.id}`);
            
            // გამოწერისას, გავაგზავნოთ ჩვენი მოწყობილობის ინფორმაცია და მოვითხოვოთ სხვებისგან
            const myDeviceType = window.innerWidth <= 900 ? 'mobile' : 'desktop';
            
            // ჩვენი მოწყობილობის ტიპის ლოკალურად დაუყოვნებლივ დაყენება
            setUserDeviceTypes(prev => ({...prev, [user.id]: myDeviceType}));

            // ჩვენი მოწყობილობის ინფორმაციის გაგზავნა სხვებისთვის
            channel.send({ type: 'broadcast', event: 'device_info', payload: { userId: user.id, deviceType: myDeviceType } });

            // ინფორმაციის მოთხოვნა სხვებისგან, რომლებიც უკვე ოთახში არიან
            channel.send({ type: 'broadcast', event: 'request_device_info', payload: {} });

          } else {
            console.error(`არხზე გამოწერის პრობლემა: ${status}`);
          }
        });

      chatChannel = supabase
        .channel(`chat_messages_channel:${room.id}`)
        .on(
          'postgres_changes',
          { event: '*', schema: 'public', table: 'chat_messages', filter: `room_id=eq.${room.id}` },
          () => { console.log('რეალურ დროში ცვლილება (chat), ვაიძულებთ განახლებას...'); forceRefreshAllData(); }
        )
        .subscribe((status) => {
          if (status !== 'SUBSCRIBED') console.error(`ჩატის არხზე გამოწერის პრობლემა: ${status}`);
          else console.log(`წარმატებით გამოიწერა არხი: chat_messages_channel:${room.id}`);
        });

      return () => {
        // გასუფთავების ფუნქცია: რეალურ დროში არხებიდან გამოწერა და ინტერვალის გასუფთავება
        if (channel) {
          supabase.removeChannel(channel);
          console.log(`room_users_channel:${room.id}-დან გამოწერილია`);
        }
        if (chatChannel) {
          supabase.removeChannel(chatChannel);
          console.log(`chat_messages_channel:${room.id}-დან გამოწერილია`);
        }
        if (intervalId) {
          clearInterval(intervalId);
          console.log('3-წამიანი ინტერვალი გასუფთავებულია');
        }
      };
    } else {
      // მდგომარეობების გასუფთავება, თუ ოთახში არ არის ან მომხმარებელი არ არის დაყენებული
      setRoomUsers([]);
      setIsBotGameOption(false);
      setIsRoomCreator(false);
      setGameState(null); // თამაშის მდგომარეობის გადატვირთვა
      // Flask (Uno) თამაშის სპეციფიკური მდგომარეობების გადატვირთვა ოთახიდან გასვლისას
      setPlayerHands({});
      setDrawPile([]);
      setDiscardPile([]);
      setCurrentTurnPlayerId(null);
      setGameDirection(1);
      setPendingDrawAmount(0);
      setActiveWildColor(null);
      setGameMessage('');
      setWinningPlayer(null);
      // ჩატის მდგომარეობების გადატვირთვა
      setChatMessages([]);
      setUserDeviceTypes({});
      setNewChatMessage('');
    }
  }, [room?.id, user]); // *** FIX: Depend on room.id to prevent re-subscriptions on every game state change ***

  // შემდეგი მოთამაშის ID-ის მიღების დამხმარე ფუნქცია
  const getNextPlayerId = (currentPlayerId, users, direction) => {
    const playerIds = users.map(u => u.id);
    // ბოტის ID-ის დამატება, თუ ეს ბოტის თამაშია
    if (gameState?.type === 'bot_game' && !playerIds.includes('bot')) {
      playerIds.push('bot');
    }
    playerIds.sort();

    if (playerIds.length === 0) return null;

    const currentIndex = playerIds.indexOf(currentPlayerId);
    let nextIndex = (currentIndex + direction + playerIds.length) % playerIds.length;
    // Fix: If a reverse card is played and there are only two players, it should still be the other player's turn.
    if (playerIds.length === 2 && direction === -1) {
        nextIndex = (currentIndex + 1) % 2;
    }
    return playerIds[nextIndex];
  };

  // ფუნქცია იმის შესამოწმებლად, შეიძლება თუ არა ბარათის თამაში
  const canPlayCard = (card, topDiscardCard, currentActiveWildColor) => {
    if (!topDiscardCard) return true; // ნებისმიერი ბარათის თამაში შეიძლება, თუ დასატოვებელი დასტა ცარიელია (არ უნდა მოხდეს პირველი ბარათის შემდეგ)

    // ველური ბარათების თამაში ყოველთვის შეიძლება
    if (card.color === 'wild') return true;

    // თუ ველური ბარათი ითამაშა მანამდე, უნდა შეესაბამებოდეს არჩეულ ფერს
    if (currentActiveWildColor) {
      return card.color === currentActiveWildColor;
    }

    // ფერის ან მნიშვნელობის შემოწმება
    return card.color === topDiscardCard.color || card.value === topDiscardCard.value;
  };

  // ბარათის თამაშის დამუშავება
  const handlePlayCard = async (cardIndex, chosenColor = null, event = null) => {
    if (isProcessingMoveRef.current || !room || !user || currentTurnPlayerId !== user.id || winningPlayer !== null) {
      setError('თქვენი სვლა არ არის, ან თამაში დასრულებულია.');
      return;
    }

    // სვლის დამუშავების დაწყების მონიშვნა
    isProcessingMoveRef.current = true;

    try {

    const currentPlayerHand = playerHands[user.id];
    const cardToPlay = currentPlayerHand[cardIndex];
    const topDiscardCard = discardPile[discardPile.length - 1];

    if (!canPlayCard(cardToPlay, topDiscardCard, activeWildColor)) {
      setError('თქვენ არ შეგიძლიათ ამ ბარათის თამაში. ის უნდა ემთხოვდეს ზედა ბარათის ფერს ან მნიშვნელობას, ან იყოს ველური ბარათი.');
      return;
    }

    // Wild card color check before starting any state changes
    if ((cardToPlay.value === 'wild' || cardToPlay.value === 'wild_draw4')) {
      if (!chosenColor || !COLORS.includes(chosenColor)) {
        setError('გთხოვთ, აირჩიოთ ფერი ველური ბარათისთვის.');
        // Do not proceed if a color isn't chosen for a wild card.
        return; // finally ბლოკი შესრულდება
      } 
    }

    // --- Animation Setup ---
    if (enableAnimations && discardPileRef.current) {
      let startRect = null;
      if (event && event.currentTarget) {
        startRect = event.currentTarget.getBoundingClientRect();
      } else if (wildCardToPlay && wildCardToPlay.index === cardIndex && wildCardToPlay.startRect) {
        startRect = wildCardToPlay.startRect;
      } else if (playerHandRef.current) {
        // Fallback for wild cards where the event is lost.
        // Find the card element in the DOM using its index.
        const cardElement = playerHandRef.current.children[cardIndex];
        if (cardElement) {
          startRect = cardElement.getBoundingClientRect();
        }
      }

      if (startRect) {
        const discardPileCardElement = discardPileRef.current.querySelector('.card');
        const endRect = discardPileCardElement
          ? discardPileCardElement.getBoundingClientRect()
          : discardPileRef.current.getBoundingClientRect(); // Fallback to pile itself if empty
        setAnimatingCardInfo({
          card: cardToPlay,
          startRect,
          endRect,
        });
      }
    }
    playSound(cardAudio, soundEffectsVolume);

    // წინა შეცდომის გასუფთავება
    setError('');

    const newPlayerHands = JSON.parse(JSON.stringify(playerHands)); // Deep copy for safety
    const newDiscardPile = [...discardPile];
    const newDrawPile = [...drawPile];
    let newCurrentTurnPlayerId = currentTurnPlayerId;
    let newGameDirection = gameDirection;
    let newPendingDrawAmount = pendingDrawAmount;
    let newActiveWildColor = null; // აქტიური ველური ფერის გადატვირთვა ბარათის თამაშის შემდეგ

    // ბარათის ამოღება ხელიდან და დასატოვებელ დასტაზე დამატება
    newPlayerHands[user.id] = newPlayerHands[user.id].filter((_, idx) => idx !== cardIndex);
    newDiscardPile.push(cardToPlay);

    // მოგების პირობის შემოწმება
    if (newPlayerHands[user.id].length === 0) {
      const finalGameState = {
        playerHands: newPlayerHands,
        drawPile: newDrawPile,
        discardPile: newDiscardPile,
        currentTurnPlayerId: null, // თამაში დასრულდა
        gameDirection: newGameDirection,
        pendingDrawAmount: 0,
        activeWildColor: null,
        winningPlayer: user.id, // გამარჯვებულის დაყენება
      };
      // Optimistic UI Update
      setPlayerHands(finalGameState.playerHands);
      setDiscardPile(finalGameState.discardPile);
      setCurrentTurnPlayerId(finalGameState.currentTurnPlayerId);
      setWinningPlayer(finalGameState.winningPlayer);
      setGameMessage(`${user.username} იმარჯვებს Flask თამაშში!`);
      // DB Update
      await updateFlaskGameState(room.id, finalGameState); // await is important here
      return;
    }

    // შემდეგი მოთამაშის განსაზღვრა და სპეციალური ბარათების ეფექტების გამოყენება
    if (cardToPlay.value === 'skip') {
      let skippedPlayerId = getNextPlayerId(user.id, roomUsersRef.current, newGameDirection);
      const skippedPlayerName = roomUsersRef.current.find(u => u.id === skippedPlayerId)?.username || (skippedPlayerId === 'bot' ? 'ბოტი' : 'უცნობი მოთამაშე');
      setGameMessage(`${user.username}-მა ითამაშა SKIP. ${skippedPlayerName}-ის სვლა გამოტოვებულია!`);
      newCurrentTurnPlayerId = getNextPlayerId(skippedPlayerId, roomUsersRef.current, newGameDirection);
    } else {
      if (cardToPlay.value === 'reverse') {
        newGameDirection *= -1;
        setGameMessage(`${user.username}-მა ითამაშა REVERSE. მიმართულება შეცვლილია!`);
      } else if (cardToPlay.value === 'draw2') {
        newPendingDrawAmount += 2;
        setGameMessage(`${user.username}-მა ითამაშა DRAW 2. შემდეგმა მოთამაშემ 2 ბარათი უნდა აიღოს!`);
      } else if (cardToPlay.value === 'wild' || cardToPlay.value === 'wild_draw4') {
        newActiveWildColor = chosenColor;
        setGameMessage(`${user.username}-მა ითამაშა WILD. ფერი შეიცვალა ${chosenColor.toUpperCase()}-ზე!`);
        if (cardToPlay.value === 'wild_draw4') {
          newPendingDrawAmount += 4;
          setGameMessage(`${user.username}-მა ითამაშა WILD DRAW 4. შემდეგმა მოთამაშემ 4 ბარათი უნდა აიღოს! ფერი შეიცვალა ${chosenColor.toUpperCase()}-ზე!`);
        }
      }
      // ყველა სხვა ბარათისთვის (skip-ის გარდა), შემდეგი მოთამაშე განისაზღვრება აქ
      newCurrentTurnPlayerId = getNextPlayerId(user.id, roomUsersRef.current, newGameDirection);
    }

    // თუ არის მომლოდინე გათამაშების რაოდენობა, გამოიყენეთ ის შემდეგ მოთამაშეზე და გამოტოვეთ მისი სვლა
    if (newPendingDrawAmount > 0 && newCurrentTurnPlayerId) {
      const targetPlayerId = newCurrentTurnPlayerId;
      const cardsToDraw = newPendingDrawAmount;
      newPendingDrawAmount = 0; // მომლოდინე გათამაშების რაოდენობის გადატვირთვა

      // ბარათების გათამაშება სამიზნე მოთამაშისთვის
      const drawnCards = newDrawPile.splice(0, cardsToDraw);
      newPlayerHands[targetPlayerId] = [...(newPlayerHands[targetPlayerId] || []), ...drawnCards];

      const targetPlayerName = roomUsersRef.current.find(u => u.id === targetPlayerId)?.username || (targetPlayerId === 'bot' ? 'ბოტი' : 'უცნობი მოთამაშე');
      setGameMessage(`${targetPlayerName}-მა აიღო ${cardsToDraw} ბარათი და კარგავს თავის სვლას!`);
      newCurrentTurnPlayerId = getNextPlayerId(targetPlayerId, roomUsersRef.current, newGameDirection); // მისი სვლის გამოტოვება
    }

    const newGameState = {
      playerHands: newPlayerHands,
      drawPile: newDrawPile,
      discardPile: newDiscardPile,
      currentTurnPlayerId: newCurrentTurnPlayerId,
      gameDirection: newGameDirection,
      pendingDrawAmount: newPendingDrawAmount,
      activeWildColor: newActiveWildColor,
      winningPlayer: null, // გამარჯვებულის გადატვირთვა, თუ თამაში მიმდინარეობს
    };

    // *** OPTIMISTIC UI UPDATE ***
    setPlayerHands(newGameState.playerHands);
    setDiscardPile(newGameState.discardPile);
    setDrawPile(newGameState.drawPile);
    setCurrentTurnPlayerId(newGameState.currentTurnPlayerId);
    setGameDirection(newGameState.gameDirection);
    setPendingDrawAmount(newGameState.pendingDrawAmount);
    setActiveWildColor(newGameState.activeWildColor);

    // Update database in the background
    await updateFlaskGameState(room.id, newGameState);

    } finally {
      // სვლის დამუშავების დასრულების მონიშვნა
      isProcessingMoveRef.current = false;
    }
  };

  // ბარათის გათამაშების დამუშავება დასატოვებელი დასტიდან
  const handleDrawCard = async () => {
    if (isProcessingMoveRef.current || !room || !user || currentTurnPlayerId !== user.id || winningPlayer !== null) {
      setError('თქვენი სვლა არ არის, ან თამაში დასრულებულია.');
      return;
    }

    isProcessingMoveRef.current = true;

    try {
      if (drawPile.length === 0) {
        setError('დასატოვებელი დასტა ცარიელია!');
        return; // finally will still run
      }
    playSound(cardAudio, soundEffectsVolume);

    setError('');

    // Create copies for modification
    const newDrawPile = [...drawPile];
    const newPlayerHands = { ...playerHands };
    const drawnCard = newDrawPile.shift(); // ერთი ბარათის აღება დასატოვებელი დასტიდან

    newPlayerHands[user.id] = [...(newPlayerHands[user.id] || []), drawnCard];

    // შემდეგი მოთამაშის განსაზღვრა - სვლა გადადის
    const newCurrentTurnPlayerId = getNextPlayerId(currentTurnPlayerId, roomUsersRef.current, gameDirection);

    const newGameState = {
      playerHands: newPlayerHands,
      drawPile: newDrawPile,
      discardPile: discardPile, // დასატოვებელი დასტა არ იცვლება
      currentTurnPlayerId: newCurrentTurnPlayerId,
      gameDirection: gameDirection,
      pendingDrawAmount: pendingDrawAmount,
      activeWildColor: activeWildColor,
      winningPlayer: null,
    };

    setPlayerHands(newGameState.playerHands);
    setDrawPile(newGameState.drawPile);
    setCurrentTurnPlayerId(newGameState.currentTurnPlayerId);

    const nextPlayerName = roomUsersRef.current.find(u => u.id === newCurrentTurnPlayerId)?.username || (newCurrentTurnPlayerId === 'bot' ? 'ბოტი' : 'უცნობი მოთამაშე');
    setGameMessage(`${user.username}-მა აიღო ბარათი. ახლა ${nextPlayerName}-ის სვლაა.`);
    await updateFlaskGameState(room.id, newGameState);

    } finally {
      isProcessingMoveRef.current = false;
    }
  };

  // ბოტის ლოგიკა Flask-ისთვის (Uno) - ძალიან მარტივი: თამაშობს პირველ სათამაშო ბარათს ან იღებს
  // Fix: The makeBotMove function will now be simplified, it will get the state directly from the component's state
  const makeBotMove = async () => {
    console.log("ბოტის სვლა დაიწყო...");

    const botHand = playerHands['bot'] || [];
    const topDiscardCard = discardPile[discardPile.length - 1];
    let localGameState = {
      playerHands: { ...playerHands },
      drawPile: [...drawPile],
      discardPile: [...discardPile],
      currentTurnPlayerId: currentTurnPlayerId,
      gameDirection: gameDirection,
      pendingDrawAmount: pendingDrawAmount,
      activeWildColor: activeWildColor,
      winningPlayer: null,
      gameMessage: ''
    };

    if (localGameState.pendingDrawAmount > 0) {
      const cardsToDraw = localGameState.pendingDrawAmount;
      const drawnCards = localGameState.drawPile.splice(0, cardsToDraw);
      localGameState.playerHands['bot'] = [...botHand, ...drawnCards];
      localGameState.currentTurnPlayerId = getNextPlayerId('bot', roomUsersRef.current, localGameState.gameDirection);
      localGameState.gameMessage = `ბოტმა აიღო ${cardsToDraw} ბარათი და კარგავს თავის სვლას!`;
      localGameState.pendingDrawAmount = 0;
      console.log("ბოტმა აიღო ბარათები (pendingDraw) და სვლა გადავიდა.");
    } else {
      // სცადეთ ბარათის თამაში
      let playedCard = null;
      let playedCardIndex = -1;
      let chosenColor = null;

      for (let i = 0; i < botHand.length; i++) {
        const card = botHand[i];
        if (canPlayCard(card, topDiscardCard, localGameState.activeWildColor)) {
          playedCard = card;
          playedCardIndex = i;
          // თუ ეს ველური ბარათია, აირჩიეთ შემთხვევითი ფერი
          if (card.color === 'wild') {
            chosenColor = COLORS[Math.floor(Math.random() * COLORS.length)];
          }
          break;
        }
      }

      if (playedCard) {
        // ბარათის თამაში
        localGameState.playerHands['bot'] = botHand.filter((_, idx) => idx !== playedCardIndex);
        localGameState.discardPile.push(playedCard);

        // ბოტის მოგების შემოწმება
        if (localGameState.playerHands['bot'].length === 0) {
          localGameState.winningPlayer = 'bot';
          localGameState.gameMessage = `ბოტი იმარჯვებს Flask თამაშში!`;
          console.log("ბოტმა მოიგო!");
          localGameState.currentTurnPlayerId = null;
        } else {
          // სპეციალური ბარათის ეფექტების გამოყენება ბოტის თამაშისთვის
          if (playedCard.value === 'skip') {
            let skippedPlayerId = getNextPlayerId('bot', roomUsersRef.current, localGameState.gameDirection);
            const skippedPlayerName = roomUsersRef.current.find(u => u.id === skippedPlayerId)?.username || (skippedPlayerId === 'bot' ? 'ბოტი' : 'უცნობი მოთამაშე');
            localGameState.gameMessage = `ბოტმა ითამაშა SKIP. ${skippedPlayerName}-ის სვლა გამოტოვებულია!`;
            localGameState.currentTurnPlayerId = getNextPlayerId(skippedPlayerId, roomUsersRef.current, localGameState.gameDirection);
            console.log("ბოტმა ითამაშა SKIP.");
          } else {
            if (playedCard.value === 'reverse') {
              localGameState.gameDirection *= -1;
              localGameState.gameMessage = `ბოტმა ითამაშა REVERSE. მიმართულება შეცვლილია!`;
              console.log("ბოტმა ითამაშა REVERSE.");
            } else if (playedCard.value === 'draw2') {
              localGameState.pendingDrawAmount += 2;
              localGameState.gameMessage = `ბოტმა ითამაშა DRAW 2. შემდეგმა მოთამაშემ 2 ბარათი უნდა აიღოს!`;
              console.log("ბოტმა ითამაშა DRAW 2.");
            } else if (playedCard.color === 'wild') {
              localGameState.activeWildColor = chosenColor;
              localGameState.gameMessage = `ბოტმა ითამაშა WILD. ფერი შეიცვალა ${chosenColor.toUpperCase()}-ზე!`;
              if (playedCard.value === 'wild_draw4') {
                localGameState.pendingDrawAmount += 4;
                localGameState.gameMessage = `ბოტმა ითამაშა WILD DRAW 4. შემდეგმა მოთამაშემ 4 ბარათი უნდა აიღოს! ფერი შეიცვალა ${chosenColor.toUpperCase()}-ზე!`;
              }
              console.log(`ბოტმა ითამაშა WILD. არჩეული ფერი: ${chosenColor}.`);
            }
            localGameState.currentTurnPlayerId = getNextPlayerId('bot', roomUsersRef.current, localGameState.gameDirection);
          }
        }
      } else {
        // ბოტს არ აქვს სათამაშო ბარათები, აიღეთ ერთი
        console.log("ბოტს არ აქვს სათამაშო ბარათი, იღებს ბარათს.");
        if (localGameState.drawPile.length === 0) {
          localGameState.gameMessage = "ბოტს არ აქვს სვლები და დასატოვებელი დასტა ცარიელია! თამაში შეიძლება გაჭედილი იყოს.";
          console.warn("Draw pile is empty, bot cannot draw.");
          localGameState.currentTurnPlayerId = getNextPlayerId('bot', roomUsersRef.current, localGameState.gameDirection);
        } else {
          const drawnCard = localGameState.drawPile.shift();
          localGameState.playerHands['bot'] = [...botHand, drawnCard];
          localGameState.gameMessage = `ბოტმა აიღო ბარათი.`;
          console.log("ბოტმა აიღო ბარათი:", drawnCard);

          // After drawing, immediately try to play if possible
          if (canPlayCard(drawnCard, topDiscardCard, localGameState.activeWildColor)) {
            console.log("ბოტმა აიღო და შეუძლია ითამაშოს გათამაშებული ბარათი.");
            localGameState.playerHands['bot'] = localGameState.playerHands['bot'].filter(card => card !== drawnCard);
            localGameState.discardPile.push(drawnCard);

            if (localGameState.playerHands['bot'].length === 0) {
              localGameState.winningPlayer = 'bot';
              localGameState.gameMessage = `ბოტი იმარჯვებს Flask თამაშში!`;
              console.log("ბოტმა მოიგო გათამაშებული ბარათით!");
              localGameState.currentTurnPlayerId = null;
            } else {
              // Apply effects of the played drawn card
              if (drawnCard.value === 'skip') {
                let skippedPlayerId = getNextPlayerId('bot', roomUsersRef.current, localGameState.gameDirection);
                const skippedPlayerName = roomUsersRef.current.find(u => u.id === skippedPlayerId)?.username || (skippedPlayerId === 'bot' ? 'ბოტი' : 'უცნობი მოთამაშე');
                localGameState.gameMessage = `ბოტმა აიღო და ითამაშა SKIP. ${skippedPlayerName}-ის სვლა გამოტოვებულია!`;
                localGameState.currentTurnPlayerId = getNextPlayerId(skippedPlayerId, roomUsersRef.current, localGameState.gameDirection);
              } else {
                if (drawnCard.value === 'reverse') {
                  localGameState.gameDirection *= -1;
                  localGameState.gameMessage = `ბოტმა აიღო და ითამაშა REVERSE. მიმართულება შეცვლილია!`;
                } else if (drawnCard.value === 'draw2') {
                  localGameState.pendingDrawAmount += 2;
                  localGameState.gameMessage = `ბოტმა აიღო და ითამაშა DRAW 2.`;
                } else if (drawnCard.color === 'wild') {
                  chosenColor = COLORS[Math.floor(Math.random() * COLORS.length)];
                  localGameState.activeWildColor = chosenColor;
                  localGameState.gameMessage = `ბოტმა აიღო და ითამაშა WILD. ფერი შეიცვალა ${chosenColor.toUpperCase()}-ზე!`;
                  if (drawnCard.value === 'wild_draw4') {
                    localGameState.pendingDrawAmount += 4;
                    localGameState.gameMessage = `ბოტმა აიღო და ითამაშა WILD DRAW 4.`;
                  }
                }
                localGameState.currentTurnPlayerId = getNextPlayerId('bot', roomUsersRef.current, localGameState.gameDirection);
              }
            }
          } else {
            // If bot drew a card but couldn't play it, just pass the turn.
            localGameState.currentTurnPlayerId = getNextPlayerId('bot', roomUsersRef.current, localGameState.gameDirection);
            localGameState.gameMessage = `ბოტმა აიღო ბარათი, მაგრამ ვერ ითამაშა, სვლა გადავიდა.`;
            console.log("ბოტმა აიღო ბარათი, მაგრამ ვერ ითამაშა, სვლა გადავიდა.");
          }
        }
      }
    }

    // Handle pending draw amount for the next player
    if (localGameState.pendingDrawAmount > 0 && localGameState.currentTurnPlayerId) {
      const targetPlayerId = localGameState.currentTurnPlayerId;
      const cardsToDraw = localGameState.pendingDrawAmount;
      localGameState.pendingDrawAmount = 0;

      const drawnCards = localGameState.drawPile.splice(0, cardsToDraw);
      localGameState.playerHands[targetPlayerId] = [...(localGameState.playerHands[targetPlayerId] || []), ...drawnCards];

      const targetPlayerName = roomUsersRef.current.find(u => u.id === targetPlayerId)?.username || 'უცნობი მოთამაშე';
      localGameState.gameMessage += ` ${targetPlayerName}-მა აიღო ${cardsToDraw} ბარათი და კარგავს თავის სვლას!`;
      localGameState.currentTurnPlayerId = getNextPlayerId(targetPlayerId, roomUsersRef.current, localGameState.gameDirection);
    }

    // Update game state in Supabase
    await updateFlaskGameState(room.id, {
      playerHands: localGameState.playerHands,
      drawPile: localGameState.drawPile,
      discardPile: localGameState.discardPile,
      currentTurnPlayerId: localGameState.winningPlayer ? null : localGameState.currentTurnPlayerId,
      gameDirection: localGameState.gameDirection,
      pendingDrawAmount: localGameState.pendingDrawAmount,
      activeWildColor: localGameState.activeWildColor,
      winningPlayer: localGameState.winningPlayer
    });
    setGameMessage(localGameState.gameMessage);
    console.log(`ბოტის სვლა დასრულდა. შემდეგი მოთამაშე: ${localGameState.currentTurnPlayerId}`);
  };

  // ეფექტი, რომელიც იწვევს ბოტის სვლას
  useEffect(() => {
    // თუ ეს ბოტის თამაშია, ახლა ბოტის სვლაა და თამაში არ დასრულებულა
    if (gameState?.type === 'bot_game' && currentTurnPlayerId === 'bot' && !winningPlayer) {
      // დაყოვნება, რათა ბოტის სვლა უფრო ბუნებრივი გამოჩნდეს
      const botMoveTimeout = setTimeout(() => {
        makeBotMove();
      }, 2000); // 2 წამიანი დაყოვნება

      // ტაიმერის გასუფთავება, თუ კომპონენტი განადგურდა ან დამოკიდებულებები შეიცვალა
      return () => clearTimeout(botMoveTimeout);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentTurnPlayerId, gameState, winningPlayer]); // makeBotMove განზრახ არის ამოღებული, რათა თავიდან ავიცილოთ ზედმეტი გადახატვა.

  // Flask თამაშის მდგომარეობის განახლების ცენტრალიზებული ფუნქცია Supabase-ში
  const updateFlaskGameState = async (roomId, newState) => {
    try {
      const { error: updateError } = await supabase
        .from('rooms')
        .update({ game_state_data: newState })
        .eq('id', roomId);

      if (updateError) {
        console.error('Flask თამაშის მდგომარეობის განახლების შეცდომა:', updateError.message);
        setError('თამაშის მდგომარეობის განახლება ვერ მოხერხდა: ' + updateError.message);
      }
    } catch (err) {
      console.error('მოულოდნელი შეცდომა Flask თამაშის მდგომარეობის განახლების დროს:', err.message);
      setError('მოულოდნელი შეცდომა თამაშის მდგომარეობის განახლების დროს: ' + err.message);
    }
  };


  const startGameWithBot = async () => {
    console.log("Flask თამაშის დაწყება ბოტთან!");
    // FIX: დავამატეთ started: true, რათა თამაშის დაფა გამოჩნდეს
    setGameState({ type: 'bot_game', started: true, opponent: 'ბოტი' });
    setError('');
  
    const fullDeck = createDeck();
    let currentDrawPile = [...fullDeck];
    let currentDiscardPile = [];
    const newPlayerHands = {};
  
    // 7 ბარათის დარიგება მოთამაშეზე
    newPlayerHands[user.id] = currentDrawPile.splice(0, 7);
    // 7 ბარათის დარიგება ბოტზე
    newPlayerHands['bot'] = currentDrawPile.splice(0, 7);
  
    // პირველი ბარათის განთავსება დასატოვებელ დასტაზე (არ უნდა იყოს wild_draw4)
    let firstCard = currentDrawPile.shift();
    while (firstCard.value === 'wild_draw4') {
      currentDrawPile.push(firstCard); // უკან დაბრუნება
      currentDrawPile = shuffleDeck(currentDrawPile); // ხელახლა არევა
      firstCard = currentDrawPile.shift();
    }
    currentDiscardPile.push(firstCard);
  
    let initialCurrentTurnPlayerId = user.id; // მომხმარებელი იწყებს
    let initialGameDirection = 1;
    let initialPendingDrawAmount = 0;
    let initialActiveWildColor = null;
    let initialGameMessage = `თამაში დაიწყო! ეს ${user.username}-ის სვლაა.`;
  
    // პირველი ბარათის ეფექტის გამოყენება, თუ ეს სპეციალური ბარათია
    if (firstCard.value === 'skip') {
      initialCurrentTurnPlayerId = 'bot'; // მომხმარებლის სვლის გამოტოვება, ბოტი იწყებს
      initialGameMessage = "პირველი ბარათი არის SKIP. თქვენი სვლა გამოტოვებულია. ბოტი იწყებს!";
    } else if (firstCard.value === 'reverse') {
      initialGameDirection = -1; // მიმართულების შეცვლა
      initialGameMessage = "პირველი ბარათი არის REVERSE. მიმართულება შეცვლილია!";
    } else if (firstCard.value === 'draw2') {
      initialPendingDrawAmount = 2;
      initialGameMessage = "პირველი ბარათი არის DRAW 2. თქვენ 2 ბარათი უნდა აიღოთ!";
    } else if (firstCard.value === 'wild' || firstCard.value === 'wild_draw4') {
      // ველური ბარათებისთვის, როგორც პირველი ბარათი, შემთხვევით აირჩიეთ ფერი
      initialActiveWildColor = COLORS[Math.floor(Math.random() * COLORS.length)];
      initialGameMessage = `პირველი ბარათი არის WILD. ფერი დაყენებულია ${initialActiveWildColor.toUpperCase()}-ზე!`;
    }
  
    // FIX: ლოკალური მდგომარეობის განახლება UI-ს მყისიერი ცვლილებისთვის
    setPlayerHands(newPlayerHands);
    setDrawPile(currentDrawPile);
    setDiscardPile(currentDiscardPile);
    setCurrentTurnPlayerId(initialCurrentTurnPlayerId);
    setGameDirection(initialGameDirection);
    setPendingDrawAmount(initialPendingDrawAmount);
    setActiveWildColor(initialActiveWildColor);
    setWinningPlayer(null);
    setGameMessage(initialGameMessage);
  
    // FIX: მონაცემთა ბაზის განახლება game_started_at-ის ჩათვლით
    const newGameStateData = {
      playerHands: newPlayerHands,
      drawPile: currentDrawPile,
      discardPile: currentDiscardPile,
      currentTurnPlayerId: initialCurrentTurnPlayerId,
      gameDirection: initialGameDirection,
      pendingDrawAmount: initialPendingDrawAmount,
      activeWildColor: initialActiveWildColor,
      winningPlayer: null
    };
  
    try {
      const { error } = await supabase
        .from('rooms')
        .update({
          game_started_at: new Date().toISOString(),
          game_state_data: newGameStateData
        })
        .eq('id', room.id);
      if (error) throw error;
    } catch (err) {
      setError('თამაშის დაწყების შეცდომა: ' + err.message);
    }
  };

  const startGame = async () => {
    if (room && user && isRoomCreator) {
      console.log("მულტიპლეიერ Flask თამაშის დაწყება!");
      setError('');

      // დარწმუნდით, რომ მინიმუმ ორი მოთამაშეა მულტიპლეიერ თამაშის დასაწყებად
      if (roomUsers.length < 2) {
        setError('მულტიპლეიერ თამაშის დასაწყებად მინიმუმ 2 მოთამაშეა საჭირო.');
        return;
      }

      const fullDeck = createDeck();
      let currentDrawPile = [...fullDeck];
      let currentDiscardPile = [];
      const newPlayerHands = {};

      // 7 ბარათის დარიგება თითოეულ მოთამაშეზე
      roomUsers.forEach(p => {
        newPlayerHands[p.id] = currentDrawPile.splice(0, 7);
      });

      // პირველი ბარათის განთავსება დასატოვებელ დასტაზე (არ უნდა იყოს wild_draw4)
      let firstCard = currentDrawPile.shift();
      while (firstCard.value === 'wild_draw4') {
        currentDrawPile.push(firstCard); // უკან დაბრუნება
        currentDrawPile = shuffleDeck(currentDrawPile); // ხელახლა არევა
        firstCard = currentDrawPile.shift();
      }
      currentDiscardPile.push(firstCard);

      let initialCurrentTurnPlayerId = roomUsers[0]?.id || null; // ოთახის მომხმარებლების პირველი მომხმარებელი იწყებს
      let initialGameDirection = 1;
      let initialPendingDrawAmount = 0;
      let initialActiveWildColor = null;

      // პირველი ბარათის ეფექტის გამოყენება, თუ ეს სპეციალური ბარათია
      if (firstCard.value === 'skip') {
        initialCurrentTurnPlayerId = getNextPlayerId(initialCurrentTurnPlayerId, roomUsers, initialGameDirection);
        setGameMessage(`პირველი ბარათი არის SKIP. ${roomUsers.find(u => u.id === initialCurrentTurnPlayerId)?.username}-ის სვლა გამოტოვებულია.`);
      } else if (firstCard.value === 'reverse') {
        initialGameDirection = -1;
        setGameMessage("პირველი ბარათი არის REVERSE. მიმართულება შეცვლილია!");
      } else if (firstCard.value === 'draw2') {
        initialPendingDrawAmount = 2;
        setGameMessage("პირველი ბარათი არის DRAW 2. შემდეგმა მოთამაშემ 2 ბარათი უნდა აიღოს!");
      } else if (firstCard.value === 'wild' || firstCard.value === 'wild_draw4') {
        initialActiveWildColor = COLORS[Math.floor(Math.random() * COLORS.length)];
        setGameMessage(`პირველი ბარათი არის WILD. ფერი დაყენებულია ${initialActiveWildColor.toUpperCase()}-ზე!`);
      }

      try {
        // ოთახის სტატუსის განახლება მონაცემთა ბაზაში თამაშის დაწყების მითითებისთვის და საწყისი თამაშის მდგომარეობის დასაყენებლად
        const { data, error } = await supabase
          .from('rooms')
          .update({
            game_started_at: new Date().toISOString(),
            game_state_data: {
              playerHands: newPlayerHands,
              drawPile: currentDrawPile,
              discardPile: currentDiscardPile,
              currentTurnPlayerId: initialCurrentTurnPlayerId,
              gameDirection: initialGameDirection,
              pendingDrawAmount: initialPendingDrawAmount,
              activeWildColor: initialActiveWildColor,
              winningPlayer: null
            }
          })
          .eq('id', room.id)
          .select()
          .single();

        if (error) {
          setError('თამაშის დაწყების შეცდომა: ' + error.message);
        } else {
          setGameState({ type: 'multiplayer', started: true });
          setRoom(data); // ლოკალური ოთახის მდგომარეობის განახლება ახალი მონაცემებით
          // ლოკალური თამაშის მდგომარეობების დაყენება საწყისი მდგომარეობის მიხედვით
          setPlayerHands(newPlayerHands);
          setDrawPile(currentDrawPile);
          setDiscardPile(currentDiscardPile);
          setCurrentTurnPlayerId(initialCurrentTurnPlayerId);
          setGameDirection(initialGameDirection);
          setPendingDrawAmount(initialPendingDrawAmount);
          setActiveWildColor(initialActiveWildColor);
          setWinningPlayer(null);
          setGameMessage(`ეს ${roomUsers.find(u => u.id === initialCurrentTurnPlayerId)?.username}-ის სვლაა!`);
        }
      } catch (err) {
        setError('მოულოდნელი შეცდომა თამაშის დაწყების დროს: ' + err.message);
      }
    } else {
      setError('თქვენ არ გაქვთ თამაშის დაწყების უფლება ან არ ხართ ოთახში.');
    }
  };

  // ოთახიდან გასვლის ახალი ფუნქცია
  const exitRoom = async () => {
    if (user && room) {
      try {
        // If the current user is the room creator, delete the room and related data.
        if (isRoomCreator) {
          console.log(`Room creator (${user.username}) is leaving. Deleting room (${room.name}).`);

          // 1. Set current_room_id to null for all users in the room to avoid foreign key violations.
          await supabase
            .from('users')
            .update({ current_room_id: null })
            .eq('current_room_id', room.id);

          // 2. Delete all chat messages associated with the room.
          await supabase
            .from('chat_messages')
            .delete()
            .eq('room_id', room.id);

          // 3. Finally, delete the room itself.
          const { error: deleteRoomError } = await supabase
            .from('rooms')
            .delete()
            .eq('id', room.id);

          if (deleteRoomError) {
            throw deleteRoomError;
          }
        } else {
          // If not the creator, just leave the room by updating their own record.
          const { error: updateError } = await supabase
            .from('users')
            .update({ current_room_id: null })
            .eq('id', user.id);

          if (updateError) {
            throw updateError;
          }
        }
      } catch (err) {
        console.error('მოულოდნელი შეცდომა ოთახიდან გასვლის დროს:', err.message);
        setError('მოულოდნელი შეცდომა ოთახიდან გასვლის დროს: ' + err.message);
        // Do not reset UI state on error, so the user can see the error and maybe try again.
        return;
      }
    }
    // ოთახთან დაკავშირებული ყველა მდგომარეობის გასუფთავება მონაცემთა ბაზის განახლების წარმატების მიუხედავად
    setRoom(null);
    setRoomUsers([]);
    setIsBotGameOption(false);
    setIsRoomCreator(false);
    setGameState(null);
    // Flask (Uno) თამაშის სპეციფიკური მდგომარეობების გადატვირთვა
    setPlayerHands({});
    setDrawPile([]);
    setDiscardPile([]);
    setCurrentTurnPlayerId(null);
    setGameDirection(1);
    setPendingDrawAmount(0);
    setActiveWildColor(null);
    setGameMessage('');
    setWinningPlayer(null);
    // ჩატის მდგომარეობების გადატვირთვა
    setChatMessages([]);
    setUserDeviceTypes({});
    setNewChatMessage('');
  };

  // ჩატის შეტყობინების გაგზავნის დამუშავება
  const handleSendChatMessage = async (e) => {
    e.preventDefault();
    const messageToSend = newChatMessage.trim();
    if (!messageToSend || !user || !room) {
      return;
    }

    // Optimistic UI: შეტყობინების დაუყოვნებლივ ჩვენება გაგზავნამდე
    const tempId = `temp_${Date.now()}`;
    const optimisticMessage = {
      id: tempId,
      message: messageToSend,
      user_id: user.id,
      users: { username: user.username }, // მიმდინარე მომხმარებლის მონაცემები ოპტიმისტური ჩვენებისთვის
      isSending: true, // ფლაგმანი სტილიზაციისთვის
      created_at: new Date().toISOString(),
    };

    setChatMessages(currentMessages => [...currentMessages, optimisticMessage]);
    setNewChatMessage(''); // ველის გასუფთავება

    try {
      const { error: insertError } = await supabase
        .from('chat_messages')
        .insert([
          { room_id: room.id, user_id: user.id, message: messageToSend }
        ]);

      if (insertError) {
        console.error('შეტყობინების გაგზავნის შეცდომა:', insertError.message);
        setError('შეტყობინების გაგზავნა ვერ მოხერხდა: ' + insertError.message);
        // შეცდომის შემთხვევაში, ოპტიმისტური განახლების გაუქმება
        setChatMessages(currentMessages => currentMessages.filter(msg => msg.id !== tempId));
        setNewChatMessage(messageToSend); // შეტყობინების დაბრუნება ველში
      }
      // წარმატების შემთხვევაში, real-time subscription განაახლებს შეტყობინებების სიას,
      // რაც ავტომატურად წაშლის ჩვენს დროებით ოპტიმისტურ შეტყობინებას.
    } catch (err) {
      console.error('მოულოდნელი შეცდომა შეტყობინების გაგზავნის დროს:', err.message);
      setError('მოულოდნელი შეცდომა შეტყობინების გაგზავნის დროს: ' + err.message);
      // მოულოდნელი შეცდომის შემთხვევაშიც, განახლების გაუქმება
      setChatMessages(currentMessages => currentMessages.filter(msg => msg.id !== tempId));
      setNewChatMessage(messageToSend);
    }
  };

  // ემოჯი-რეაქციის გაგზავნა
  const sendEmojiReaction = async (emojiObject) => {
    if (!room || !user) return;

    // ემოჯის ლოკალურად დამატება ანიმაციისთვის და ავტომატური წაშლისთვის
    const reactionId = Date.now() + Math.random(); // უნიკალური ID შეჯახების თავიდან ასაცილებლად
    const newReaction = {
      id: reactionId,
      emoji: emojiObject.emoji,
      style: {
        left: `${Math.random() * 80 + 10}%`, // შემთხვევითი ჰორიზონტალური პოზიცია
      }
    };
    setReactions(currentReactions => [...currentReactions, newReaction]);
    setTimeout(() => {
      setReactions(currentReactions => currentReactions.filter(r => r.id !== reactionId));
    }, 2900); // ანიმაციის დასრულებამდე ცოტა ხნით ადრე წაშლა

    const reactionPayload = {
      type: 'broadcast',
      event: 'emoji_reaction',
      payload: { emoji: emojiObject.emoji, senderId: user.id }, // გაგზავნა სხვა მოთამაშეებთან
    };

    try {
      await supabase.channel(`room_users_channel:${room.id}`).send(reactionPayload);
    } catch (error) {
      console.error('ემოჯი-რეაქციის გაგზავნის შეცდომა:', error);
    }
    setShowEmojiPicker(false);
  };

  // დასტის ვიზუალური სისქის გამოსათვლელი ლოგიკა
  const drawPileDepth = Math.min(Math.floor(drawPile.length / 4), 12); // ვიზუალური "სიღრმე", მაქს. 12
  const drawPileStyle = {
    // CSS ცვლადების გამოყენება დინამიური სტილებისთვის
    '--stack-depth': `${drawPileDepth}px`,
    '--stack-blur': `${drawPileDepth * 1.5}px`,
    '--stack-rotate-before': `${-6 - drawPileDepth * 0.3}deg`,
    '--stack-rotate-after': `${5 + drawPileDepth * 0.3}deg`,
    '--hover-depth': `${drawPileDepth + 8}px`, // ჰოვერის ეფექტისთვის
    '--hover-blur': `${(drawPileDepth + 8) * 1.5}px`,
  };

  const opponents = roomUsers.filter(u => u.id !== user.id);

  return (
    <div className="App">
      {animatingCardInfo && (
        <div
          key={animatingCardInfo.startRect.top}
          className="animating-card-wrapper"
          onAnimationEnd={() => setAnimatingCardInfo(null)}
          style={{
            '--start-top': `${animatingCardInfo.startRect.top}px`,
            '--start-left': `${animatingCardInfo.startRect.left}px`,
            '--start-width': `${animatingCardInfo.startRect.width}px`,
            '--start-height': `${animatingCardInfo.startRect.height}px`,
            '--end-top': `${animatingCardInfo.endRect.top}px`,
            '--end-left': `${animatingCardInfo.endRect.left}px`,
            '--end-width': `${animatingCardInfo.endRect.width}px`,
            '--end-height': `${animatingCardInfo.endRect.height}px`,
          }}
        >
          {(() => {
            const card = animatingCardInfo.card;
            const cornerSymbol = getCardCornerSymbol(card);
            const isNumeric = !isNaN(parseInt(card.value, 10));
            const centerText = getCardDisplayText(card);
            const centerClassName = isNumeric ? 'numeric' : 'special-symbol';
            return (
              <div className={`card ${card.color} value-${card.value}`}>
                <span className="card-corner top-left">{cornerSymbol}</span>
                {card.value === 'skip' ? <SkipIcon /> :
                 card.value === 'reverse' ? <ReverseIcon /> :
                 (
                  <span className={`card-center-text ${centerClassName}`}>{centerText}</span>
                )}
                <span className="card-corner bottom-right">{cornerSymbol}</span>
              </div>
            );
          })()}
        </div>
      )}
      <div className="main-content-wrapper"> {/* ახალი შეფუთვა ძირითადი კონტენტისა და ჩატისთვის */}
        <div className="container">
          {!user ? (
            <div className="auth-container">
              {authMode === 'login' ? (
                <div className="auth-section">
                  <h2 className="section-title bario  ">ავტორიზაცია</h2>
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="მომხმარებლის სახელი"
                    className="input-field"
                  />
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="პაროლი"
                    className="input-field"
                  />
                  <button onClick={handleLogin} className="primary-button">შესვლა</button>
                  {error && <p className="error-message">{error}</p>}
                  <button onClick={() => { setAuthMode('register'); setError(''); setUsername(''); setPassword(''); setConfirmPassword(''); }} className="toggle-auth-button secondary-button">
                    რეგისტრაცია
                  </button>
                </div>
              ) : (
                <div className="auth-section">
                  <h2 className="section-title bario">რეგისტრაცია</h2>
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="მომხმარებლის სახელი"
                    className="input-field"
                  />
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="პაროლი"
                    className="input-field"
                  />
                  <input
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="გაიმეორეთ პაროლი"
                    className="input-field"
                  />
                  <button onClick={handleRegister} className="primary-button">რეგისტრაცია</button>
                  {error && <p className="error-message">{error}</p>}
                  <button onClick={() => { setAuthMode('login'); setError(''); setUsername(''); setPassword(''); setConfirmPassword(''); }} className="toggle-auth-button secondary-button">
                    ავტორიზაციაზე დაბრუნება
                  </button>
                </div>
              )}
            </div>
          ) : isAdminView ? (
            // ადმინის გვერდის ჩვენება
            <AdminPage user={user} onBack={() => setIsAdminView(false)} />
          ) 
          : !room ? (
            <div className="room-section">
              <div className="room-tabs">
                <button
                  className={`tab-button ${roomMode === 'create' ? 'active' : ''}`}
                  onClick={() => setRoomMode('create')}
                >
                  ოთახის შექმნა
                </button>
                <button
                  className={`tab-button ${roomMode === 'join' ? 'active' : ''}`}
                  onClick={() => setRoomMode('join')}
                >
                  ოთახში შესვლა
                </button>
              </div>
              <div className="room-section-content">
                {roomMode === 'create' ? (
                  <div className="room-form create-form">
                    <h3 className="section-title">ახალი ოთახის შექმნა</h3>
                    <input
                      type="text"
                      value={roomName}
                      onChange={e => setRoomName(e.target.value)}
                      placeholder="ოთახის სახელი"
                      className="input-field"
                      required
                    />
                    <input
                      type="password"
                      value={createRoomPassword}
                      onChange={e => setCreateRoomPassword(e.target.value)}
                      placeholder="პაროლი (არასავალდებულო)"
                      className="input-field"
                    />
                    <div className="max-players-selector">
                      <div className="player-count-buttons">
                        {[1, 2, 3, 4].map(num => (
                          <button
                            key={num}
                            type="button"
                            className={`player-count-button ${maxPlayers === num ? 'active' : ''}`}
                            onClick={() => setMaxPlayers(num)}
                          >
                            {num} 
                          </button>
                        ))}
                      </div>
                    </div>
                    <button onClick={handleCreateRoom} className="primary-button">შექმნა</button>
                  </div>
                ) : (
                  <div className="room-form join-form">
                    <h3 className="section-title">არსებულ ოთახში შესვლა</h3>
                    <input type="text" value={roomName} onChange={e => setRoomName(e.target.value)} placeholder="ოთახის სახელი" className="input-field" required />
                    <input
                      type="password"
                      value={roomKey}
                      onChange={e => setRoomKey(e.target.value)}
                      placeholder="პაროლი"
                      className="input-field"
                    />
                    <button onClick={handleJoinRoom} className="primary-button">შესვლა</button>
                  </div>
                )}

                {/* ადმინის ღილაკი */}
                {user && user.role === 'admin' && (
                  <button onClick={() => setIsAdminView(true)} className="secondary-button" style={{ marginTop: '10px' }}>
                    ადმინის პანელი
                  </button>
                )}

              

                {showExistingRooms && (
                  <div className="existing-rooms-list">
                    {existingRooms.length > 0 ? (
                      existingRooms.map(roomItem => (
                        <div
                          key={roomItem.id}
                          className="existing-room-item"
                          onClick={() => {
                            setRoomName(roomItem.name);
                            setRoomKey(roomItem.room_key);
                            setShowExistingRooms(false);
                            setError('');
                          }}
                        >
                          {roomItem.name}
                        </div>
                      ))
                    ) : (
                      <p>ოთახები არ არის.</p>
                    )}
                  </div>
                )}

              </div>
            </div>
          ) : (
            <div className="game-section">
              {/* Conditionally render section-title and room-info */}
              <div className="emoji-reaction-area">
                {/* შემოსული ემოჯების ჩვენება */}
                {reactions.map(reaction => (
                  <span key={reaction.id} className="reaction-emoji" style={reaction.style}>
                    {reaction.emoji}
                  </span>
                ))}
                {/* მოწყობილობის ინდიკატორები */}
                {gameState?.type === 'bot_game' && gameState?.started ? (
                  <div className="device-indicator" title="თქვენ თამაშობთ ბოტთან (კომპიუტერი)">
                    <DesktopIcon />
                  </div>
                ) : (
                  opponents.map(opponent => {
                    const deviceType = userDeviceTypes[opponent.id];
                    if (!deviceType) return null; // Don't render if device type is unknown
                    return (
                      <div key={opponent.id} className="device-indicator" title={`${opponent.username} იყენებს ${deviceType === 'mobile' ? 'მობილურს' : 'კომპიუტერს'}`}>
                        {deviceType === 'mobile' ? <MobileIcon /> : <DesktopIcon />}
                      </div>
                    );
                  })
                )}
                {/* პარამეტრების ღილაკი */}
                <button className="settings-button" onClick={() => setShowSettings(true)} title="პარამეტრები">
                  <SettingsIcon />
                </button>

                {/* სვლის ინდიკატორი */}
                {gameState?.started && !winningPlayer && (
                  <div className={`turn-indicator-button ${currentTurnPlayerId === user?.id ? 'my-turn' : 'opponent-turn'}`}>
                    {currentTurnPlayerId === user?.id ? 'სვლა' : 'სვლა'}
                  </div>
                )}

                {/* ემოჯის ამომრჩევის ღილაკი */}
                <button className="emoji-picker-button" onClick={() => setShowEmojiPicker(!showEmojiPicker)} title="ემოჯის გაგზავნა">
                  <svg fill="#ffffff4d" width="24px" height="24px" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12,2 C17.5228475,2 22,6.4771525 22,12 C22,17.5228475 17.5228475,22 12,22 C6.4771525,22 2,17.5228475 2,12 C2,6.4771525 6.4771525,2 12,2 Z M12,4 C7.581722,4 4,7.581722 4,12 C4,16.418278 7.581722,20 12,20 C16.418278,20 20,16.418278 20,12 C20,7.581722 16.418278,4 12,4 Z M16,14 C16,16.209139 14.209139,18 12,18 C9.85780461,18 8.10892112,16.3160315 8.00489531,14.1996403 L8,14 L16,14 Z M8.5,8 C9.32842712,8 10,8.67157288 10,9.5 C10,10.3284271 9.32842712,11 8.5,11 C7.67157288,11 7,10.3284271 7,9.5 C7,8.67157288 7.67157288,8 8.5,8 Z M15.5,8 C16.3284271,8 17,8.67157288 17,9.5 C17,10.3284271 16.3284271,11 15.5,11 C14.6715729,11 14,10.3284271 14,9.5 C14,8.67157288 14.6715729,8 15.5,8 Z"/>
                  </svg>
                </button>
                {/* ემოჯების ამომრჩევი */}
                {showEmojiPicker && (
                  <div className="emoji-picker-container">
                    <EmojiPicker onEmojiClick={sendEmojiReaction} theme="dark" />
                  </div>
                )}
              </div>
              {!gameState?.started && (
                <>
                  <h2 className="section-title oto">გამარჯობა <span>{truncateUsername(user.username)}</span> თქვენ იმყოფებით ოთახში : <span>{room.name}</span></h2>
                  <div className="room-info">
                    <h3>ოთახშია : <span>{roomUsers.length}</span></h3>
                    <ul className="player-list">
                      {roomUsers.length > 0 ? (
                        roomUsers.map(u => (                          <li className='device-indicator' key={u.id}>{truncateUsername(u.username)}</li>
                        ))
                      ) : (
                        <li>ოთახში არავინ არ არის შემოსული</li>
                      )}
                    </ul>
                  

                    {/* თამაშის დაწყების ღილაკის ჩვენება მხოლოდ შემქმნელისთვის და თუ თამაში არ დაწყებულა და მინიმუმ 2 მოთამაშეა */}
                    {isRoomCreator && roomUsers.length > 1 && (
                      <div className="start-game-section">
                        <button onClick={startGame} className="primary-button ">დაიწყე თამაში</button>
                      </div>
                    )}
                    {isRoomCreator && roomUsers.length === 1 && isBotGameOption && (
                      <div className="bot-option">
                        <p>თუ არავინ შემოგიერთდებათ, შეგიძლიათ ბოტთან ითამაშოთ:</p>
                        <button onClick={startGameWithBot} className="primary-button">ითამაშე ბოტთან</button>
                      </div>
                    )}
                    {/* ოთახიდან გასვლის ღილაკი */}
                  </div>
                </>
              )}

              {/* Opponent display */}
              {gameState?.started && (
                <div className="opponents-display-area">
                  {gameState.type === 'bot_game' ? (
                    <div className="opponent-info">
                      <span className="opponent-name opponent-turn">{truncateUsername("ბოტი")}</span>
                      {windowWidth > 900 && (
                        <span className="opponent-card-count">
                          ({playerHands['bot']?.length || 0} კარტი)
                        </span>
                      )}
                    </div>
                  ) : (
                    opponents.map(opponent => (                      <div key={opponent.id} className="opponent-info">
                        <span className="opponent-name">{truncateUsername(opponent.username)}</span>
                        {windowWidth > 900 && (
                          <span className="opponent-card-count">({playerHands[opponent.id]?.length || 0} კარტი)</span>
                        )}
                      </div>
                    ))
                  )}
                </div>
              )}

              {/* თამაშის არე gameState-ის მიხედვით */}
              {gameState?.started ? (
                <div className="game-area">
                  <h3>FLASKCARD თამაში მიმდინარეობს ახლა !</h3>
                  <p className="game-message area">{gameMessage}</p>

                  {winningPlayer ? (
                    <div className="game-over-section">
                      <p className="game-result">
                        {winningPlayer === 'draw' ? "ფრეა!" : `გამარჯვებული: ${truncateUsername(roomUsers.find(u => u.id === winningPlayer)?.username || (winningPlayer === 'bot' ? 'ბოტი' : 'უცნობი მოთამაშე'))}`}
                      </p>
                      <button onClick={exitRoom} className="secondary-button">
                        {isRoomCreator ? 'ოთახის დახურვა' : 'ოთახიდან გასვლა'}
                      </button>
                    </div>
                  ) : (
                    <div className="flask-game-board">
                      <div className="piles">
                        <div className="draw-pile">
                          <button
                            onClick={handleDrawCard}
                            disabled={currentTurnPlayerId !== user.id || winningPlayer !== null}
                            className="draw-card-button pop"
                            style={drawPileStyle}
                          >
                            <span className="card-count-indicator">{drawPile.length}</span>
                          </button>
                        </div>
                        <div className="discard-pile" ref={discardPileRef}>
                          {discardPile.length > 0 ? (
                            (() => {
                              const topCard = discardPile[discardPile.length - 1];                              const isWild = topCard.value === 'wild' || topCard.value === 'wild_draw4';
                              const isWildActive = isWild && activeWildColor;
                              const cornerSymbol = getCardCornerSymbol(topCard);
                              const isNumeric = !isNaN(parseInt(topCard.value, 10));
                              const centerText = getCardDisplayText(topCard);
                              const centerClassName = isNumeric ? 'numeric' : 'special-symbol';
                              // Hide the top card if it's the one being animated onto the pile
                              const isBeingAnimated = animatingCardInfo &&
                                                      discardPile.length > 0 &&
                                                      JSON.stringify(animatingCardInfo.card) === JSON.stringify(topCard);
                              
                              const cardClasses = [
                                'card',
                                isWildActive ? activeWildColor : topCard.color,
                                `value-${topCard.value}`,
                                isBeingAnimated ? 'is-hidden-for-animation' : '',
                                isWildActive ? 'is-wild-active' : ''
                              ].join(' ');

                              return (<div className={cardClasses}>
                                <span className="card-corner top-left">{cornerSymbol}</span>
                                {topCard.value === 'skip' ? <SkipIcon /> :
                                 topCard.value === 'reverse' ? <ReverseIcon /> :
                                 (
                                  <span className={`card-center-text ${centerClassName}`}>{centerText}</span>
                                )}
                                <span className="card-corner bottom-right">{cornerSymbol}</span>
                                {isWildActive && <div className={`active-wild-color ${activeWildColor}`} />}
                              </div>);
                            })()
                          ) : (
                            <div className="card empty">ცარიელი</div>
                          )}
                        </div>
                      </div>

                      <div className="player-hands-section">
                        <div className="player-hands-header">
                          <h4>თქვენ გაქვთ ({playerHands[user.id]?.length || 0} კარტი)</h4>
                          <button onClick={exitRoom} className="surrender-button" title="ოთახიდან გასვლა">
                            <ExitIcon />
                          </button>
                        </div>
                        <div className="player-hand-container">
                          {showScrollButtons.left && (
                            <button className="scroll-button left" onClick={() => handleScroll('left')}>
                              &#8249;
                            </button>
                          )}
                          <div
                            className="player-hand"
                            ref={playerHandRef}
                            onScroll={checkScrollability}
                            onMouseDown={handleMouseDown}
                            onMouseUp={handleMouseLeaveOrUp}
                            onMouseLeave={handleMouseLeaveOrUp}
                            onMouseMove={handleMouseMove}>
                            {(playerHands[user.id] || []).map((card, index) => {
                              const cornerSymbol = getCardCornerSymbol(card);
                              const isNumeric = !isNaN(parseInt(card.value, 10));
                              const centerText = getCardDisplayText(card);
                              const centerClassName = isNumeric ? 'numeric' : 'special-symbol';
                              return (
                                <button
                                  key={index}
                                  className={`card ${card.color} value-${card.value}`}
                                  onMouseMove={(event) => {
                                    const cardRect = event.currentTarget.getBoundingClientRect();
                                    const x = event.clientX - cardRect.left;
                                    const y = event.clientY - cardRect.top;
                                    event.currentTarget.style.setProperty('--mouse-x', `${x}px`);
                                    event.currentTarget.style.setProperty('--mouse-y', `${y}px`);
                                  }}
                                  onClick={(event) => {
                                    if (card.color === 'wild' || card.value === 'wild_draw4') {
                                      setWildCardToPlay({ index, startRect: event.currentTarget.getBoundingClientRect() });
                                      setShowColorPicker(true);
                                    } else {
                                      handlePlayCard(index, null, event);
                                    }
                                  }}
                                  disabled={currentTurnPlayerId !== user.id || winningPlayer !== null || !canPlayCard(card, discardPile[discardPile.length - 1], activeWildColor)}
                                >
                                  <span className="card-corner top-left">{cornerSymbol}</span>
                                  {card.value === 'skip' ? <SkipIcon /> :
                                   card.value === 'reverse' ? <ReverseIcon /> :
                                   (
                                    <span className={`card-center-text ${centerClassName}`}>{centerText}</span>
                                  )}
                                  <span className="card-corner bottom-right">{cornerSymbol}</span>
                                </button>
                              );
                            })}
                          </div>
                          {showScrollButtons.right && (
                            <button className="scroll-button right" onClick={() => handleScroll('right')}>
                              &#8250;
                            </button>
                          )}
                        </div>
                      </div>
                      </div>
                  )}
                </div>
              ) : (
                <div className="waiting-area">
                  <p>ველოდებით Flask თამაშის დაწყებას...</p>
                  {!isRoomCreator && roomUsers.length > 1 && (
                    <p>ველოდებით ოთახის შემქმნელს თამაშის დასაწყებად.</p>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
        {room && ( // ჩატის ჩვენება მხოლოდ იმ შემთხვევაში, თუ მომხმარებელი ოთახშია
          <div className="chat-section">
            <h3>ოთახის სასაუბრო</h3>
            <div className="chat-messages">
              {chatMessages.map((msg) => (
                <div key={msg.id} className={`chat-message ${msg.isSending ? 'sending' : ''}`}>                  <strong>{truncateUsername(msg.users.username)}:</strong> {msg.message}
                </div>
              ))}
              <div ref={chatMessagesEndRef} /> {/* ავტო-გადახვევისთვის */}
            </div>
            <form onSubmit={handleSendChatMessage} className="chat-input-form">
              <input
                type="text"
                value={newChatMessage}
                onChange={(e) => setNewChatMessage(e.target.value)}
                placeholder="შეიყვანეთ შეტყობინება..."
                className="chat-input-field"
              />
              <button type="submit" className="chat-send-button">გაგზავნა</button>
            </form>
          </div>
        )}
        {showTurnNotification && (
          <div className="turn-notification">
            მოწინააღმდეგე მორჩა სვლას , შენი სვლაა !
          </div>
        )}
        {showSettings && (
          <SettingsModal
            onClose={() => setShowSettings(false)}
            soundVolume={soundEffectsVolume}
            onSoundVolumeChange={setSoundEffectsVolume}
            animationsEnabled={enableAnimations}
            onAnimationsChange={setEnableAnimations}
          />
        )}
        <ErrorModal message={error} onClose={() => setError('')} />
        {showColorPicker && (
          <ColorPickerModal
            onClose={() => {
              setShowColorPicker(false);
              setWildCardToPlay(null);
            }}
            onColorSelect={(color) => {
              if (wildCardToPlay) {
                handlePlayCard(wildCardToPlay.index, color, null);
              }
              setShowColorPicker(false);
              setWildCardToPlay(null);
            }}
          />
        )}
      </div>
    </div>
  );
}

export default App;